#include<iostream>
using namespace std;
class TV
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter price of TV:";
cin>>p;
}
void printlnformation()
{
cout<<"Price of TV is :"<<p<<endl;
}
};
class Fridge
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter price of Fridge :"<<p<<endl;
cin>>p;
}
void printInformation()
{
cout<<"Price of Fridge is :"<<p<<endl;
}
};

int main()
{
TV t;
t.askInformation();
Fridge f;
f.askInformation();
cout<<"Total cost of TV and Fridge is"<<t.p+f.p<<endl;
return 0;
}