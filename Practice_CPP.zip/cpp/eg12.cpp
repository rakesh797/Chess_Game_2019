#include<iostream>
using namespace std;
int add(int p,int q)
{
return p+q;
}
float add(float p,float q)
{
return p+q;
}
int main()
{
cout<<"Total of 10 and 20 is"<<add(10,20)<<endl;
cout<<"Total of 10.2 and 20.3 is"<<add(10.2,20.3)<<endl;
return 0;
}