#include<stdio.h>
#include<malloc.h>
struct Node
{
int num;
struct Node *next;
};
struct Node *start=NULL;
int main()
{
int x;
int ch,num,pos;
struct Node *t,*j;
struct Node *p1,*p2;
while(1)
{
printf("1. Add the node at the end\n");
printf("2. Insert node at the top\n");
printf("3. Insert node at the position\n");
printf("4. Remove the node at the Position\n");
printf("5. traverse top to bottom\n");
printf("6. traverse Bottom to top\n");
printf("7. Exit\n");
printf("Enter the number:");
scanf("%d",&ch);
if(ch==1)
{
printf("Enter the number:");
scanf("%d",&num);
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
j=start;
while(j->next!=NULL)
{
j=j->next;
}
j->next=t;
}
}
}
if(ch==2)
{
printf("Enter the number:");
scanf("%d",&num);
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
t->next=start;
start=t;
}
}
if(ch==3)
{
printf("Enter the number:");
scanf("%d",&num);
printf("Enter the position:");
scanf("%d",&pos);
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1=NULL)
{
if(start=NULL)
{
start=t;
}
else
{
p2->next=t;
}
}
else
{
if(p1==start)
{
t->next=start;
start=t;
}
else
{
p2->next=t;
t->next=p1;
}
}
}
if(ch==4)
{
printf("Enter the pos");
scanf("%d",&pos);
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1==NULL)
{
printf("Invalid position\n");
}
if(p1==start)
{
start=start->next;
}
else
{
p2->next=p1->next;
}
free(p1);
}
if(ch==5)
{
t=start;
while(t!=NULL)
{
printf("%d\n",t->num);
t->next;
}
}
return 0;
}