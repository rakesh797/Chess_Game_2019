#include<stdio.h>
int main()
{
int y,x[10];
int k,j,i,m,g;
for(y=0;y<10;y++)
{
printf("Enter the number:");
scanf("%d",&x[y]);
}
i=1;
while(i<=9)
{
m=i;
do
{
k=(m-1)/2;
if(x[k]<x[m])
{
g=x[k];
x[k]=x[i];
x[i]=g;
}
m=k;
}while(m!=0);
i++;
}
for(j=9;j>=0;j--)
{
g=x[0];
x[0]=x[j];
x[j]=g;
k=0;
do{
m=2*k+1;
if(x[m]<x[m+1] && m<j-1)
{
m++;
}
if(x[k]<x[m] && m<j)
{
g=x[k];
x[k]=x[m];
x[m]=g;
}
m=k;
}while(m<j);
}
return 0;
}