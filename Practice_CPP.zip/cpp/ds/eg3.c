#include<stdio.h>
int main()
{
int y,a[10];
int e,m,f,g;
for(y=0;y<10;y++)
{
printf("Enter the number:");
scanf("%d",&a[y]);
}
e=0;
while(e<=8)
{
m=e;
f=e+1;
while(f<=9)
{
if(a[m]>a[f])
{
f=m;
}
f++;
}
g=a[m];
a[m]=a[e];
a[e]=g;
e++;
}
for(y=0;y<=9;y++)
{
printf("%d\n",a[y]);
}
return 0;
}