#include<stdio.h>
#include<malloc.h>
struct Node
{
int num;
struct Node *prev,*next;
};
struct Node *start=NULL,*end=NULL;
int main()
{
int ch,x,num,pos;
struct Node *t,*j,*p1;
while(1)
{
printf("Add the node at the end\n");
printf("Insert the node at top\n");
printf("Insert the node at position\n");
printf("Remove the node at the position\n");
printf("traverse top to Bottom\n");
printf("traverse Bottom to top\n");
printf("Exit\n");
printf("Enter the choice:");
scanf("%d",&ch);
if(ch==1)
{
printf("Enter the number:");
scanf("%d",&num);
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
t->prev=NULL;
if(start==NULL)
{
start=t;
end=t;
}else
{
end->next=t;
t->prev=end;
end=t;
}
}
if(ch==2)
{
printf("Enter the number:");
scanf("%d",&num);
t->num=num;
t->next=NULL;
t->prev=NULL;
if(start==NULL)
{
start=t;
end=t;
}else
{
start->prev=t;
t->next=start;
start=t;
}
}
if(ch==3)
{
printf("Enter the number:");
scanf("%d",&num);
printf("Enter the position to remove:");
scanf("%d",&pos);
t=(struct Node *)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
t->prev=NULL;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p1=p1->next;
x++;
}
if(p1==NULL)
{
if(start==NULL)
{
start=t;
}
else
{
end->next=t;
t->prev=end;
end=t;
}
}else
{
if(p1==start)
{
start->prev=t;
t->next=start;
start=t;
}else
{
p1->prev->next=t;
t->prev=p1->prev;
t->next=p1;
p1->prev=t;
}
}
}
if(ch==4)
{
printf("Enter the position to remove:");
scanf("%d",&pos);
x=1;
while(x<pos && p1!=NULL)
{
p1=p1->next;
x++;
}
if(p1==NULL)
{
printf("Invalid position\n");
continue;
}
if(p1==start && p1==end)
{
start=NULL;
end=NULL;
}
else
{
if(p1==start)
{
start=start->next;
start->prev=NULL;
}
else
{
if(p1==end)
{
end=end->prev;
end->next=NULL;
}
else
{
p1->prev->next=p1->next;
p1->next->prev=p1->prev;
}
}
}
}
if(ch==5)
{
t=start;
while(t!=NULL)
{
printf("%d\n",t->num);
t=t->next;
}
}
if(ch==6)
{
t=end;
while(t!=NULL)
{
printf("%d\n",t->num);
t=t->prev;
}
}
if(ch==7)
{
break;
}
}
return 0;
}