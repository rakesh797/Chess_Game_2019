#include<stdio.h>
int main()
{
int y,a[10];
int e,f,m,g;
for(y=0;y<10;y++)
{
printf("Enter the number:");
scanf("%d",&a[y]);
}
m=8;
while(m>=0)
{
e=0;
f=1;
while(e<=m)
{
if(a[f]<a[e])
{
g=a[f];
a[f]=a[e];
a[e]=g;
}
e++;
f++;
}
m--;
}
for(y=0;y<10;y++)
{
printf("%d\n",a[y]);
}
return 0;
}