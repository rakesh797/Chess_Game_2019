#include<stdio.h>
#include<malloc.h>
struct Node
{
int num;
struct Node *next;
};
struct Node *start=NULL;
void atTheEnd(int num)
{
struct Node *t,*j;
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
j=start;
while(j->next!=NULL)
{
j=j->next;
}
j->next=t;
}
}
void insertAtTheTop(int num)
{
struct Node *t;
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
t->next=start;
start=t;
}
}
void insetAtPosition(int num,int pos)
{
struct Node *p1,*p2;
int x;
struct Node *t;
t=(struct Node*)malloc(sizeof(struct Node));
t->num=num;
t->next=NULL;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1=NULL)
{
if(start=NULL)
{
start=t;
}
else
{
p2->next=t;
}
}
else
{
if(p1==start)
{
t->next=start;
start=t;
}
else
{
p2->next=t;
t->next=p1;
}
}
}
void removeFromPosition(int pos)
{
struct Node *p1,*p2;
int x;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1==NULL)
{
printf("Invalid position");
}
if(p1==start)
{
start=start->next;
}
else
{
p2->next=p1->next;
}
free(p1);
}
}
void traverseTopToBottom()
{
struct Node *t;
t=start;
while(t!=NULL)
{
printf("%d\n",t->num);
t=t->next;
}
}
void traverseBottomToTop(struct Node *t);
{
if(t=NULL)
{
traverseBottomToTop(t->next);
printf("%d\n",t->num);
}
}
}
int main()
{
int ch,num,pos;
while(1)
{
printf("1.Add at the end\n");
printf("2. insert at the top\n");
printf("3. insert at position\n");
printf("4. remove from the pos\n");
printf("5. traverse top bottom\n");
printf("6. traverse bottom to top\n");
printf("7. Exit\n");
printf("Enter your choice");
scanf("%d",&ch);
if(ch==1)
{
printf("Enter the num:");
scanf("%d",&num);
atTheEnd(num);
}
if(ch==2)
{
printf("Enter the num:");
scanf("%d",&num);
insertAtTheTop(num);
}
if(ch==3)
{
printf("Enter the num:");
scanf("%d",&num);
printf("Enter the pos:");
scanf("%d",&pos);
insetAtPosition(num,pos);
}
if(ch==4)
{
printf("Enter the pos:");
scanf("%d",&pos);
removeFromPosition(pos)
}
if(ch==5)
{
traverseTopToBottom();
}
if(ch==6)
{
traverseBottomToTop(start);
}
if(ch==7) break;
}
return 0;
}