#include<stdio.h>
int main()
{
int x[10];
int p,j,num,y;
int distanceFactor,size;
size=10;
for(y=0;y<size;y++)
{
printf("Enter the number:");
scanf("%d",&x[y]);
}
distanceFactor=size/2;
while(distanceFactor>0)
{
y=0+distanceFactor;
while(y<=9)
{
p=y;
num=x[p];
j=p-distanceFactor;
while(j>=0)
{
if(x[j]<=num)
{
break;
}
x[j+distanceFactor]=x[j];
j=j-distanceFactor;
p=p-distanceFactor;
}
x[p]=num;
y=y+distanceFactor;
}
distanceFactor=distanceFactor/2;
}
for(y=0;y<size;y++)
{
printf("%d\n",x[y]);
}
return 0;
}