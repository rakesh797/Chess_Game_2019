#include<stdio.h>
int main()
{
int y,a[10];
for(y=0;y<10;y++) 
{
printf("Enter the number:");
scanf("%d",&a[y]);
}
int e,num,p,j;
e=1;
while(e<=9)
{
p=e;
num=a[p];
j=p-1;
while(j>=0)
{
if(a[j]<=num)
{
break;
}
a[j+1]=a[j];
j--;
p--;
}
a[p]=num;
e++;
}
for(y=0;y<10;y++)
{
printf("%d\n",a[y]);
}
return 0;
}