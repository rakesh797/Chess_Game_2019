#include<iostream>
class HeapSort
{
private:
int k,m,e;
e=0;
while(e
};
int main()
{
int x[10],y;
HeapSort h;
for(y=0;y<10;y++)
{
printf("Enter the number:");
scanf("%d",&x[y]);
}
heapSort(x,10);
for(y=0;y<10;y++);
{
printf("%d",x[y]);
}
return 0;
}

