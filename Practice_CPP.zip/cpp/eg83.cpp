#include<iostream>
using namespace std;
void lmn()
{
int *x;
x=new int;
*x=60;
cout<<*x<<endl;
}
int main()
{
lmn();
cout<<"Ujjain"<<endl;
return 0;
}