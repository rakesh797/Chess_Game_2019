#include<iostream>
using namespace std;
class Bulb
{
private:
int w;
public:
Bulb(cont Bulb &e)
{
w=e.w;
}
void setWattage(int e)
{
w=e;
}
int getWattage()
{
return w;
}
};
int main()
{
Bulb g;
g.setWattage(100);
cout<<"Wattage is "<<g.getWattage()<<endl;
Bulb t(g);
cout<<"Wattage is "<<t.getWattage()<<endl;
return 0;
}