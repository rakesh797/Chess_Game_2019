#include<iostream>
using namespace std;
class Rectangle
{
int length;
int breadth;
public:
void setLength(int e)
{
length=e;
}
void setBreadth(int e)
{
breadth=e;
}
int getLength()
{
return length;
}
int getLenth()
{
return breadth;
}
};
class Box:private Rectangle
{
int height;
public:
void setHeight(int e)
{
height=e;
}
int getHeight()
{
return height;
}
};
int main()
{
Box x;
x.setHeight(40);
cout<<"Height:"<<x.getHeight()<<endl;
return 0;
}