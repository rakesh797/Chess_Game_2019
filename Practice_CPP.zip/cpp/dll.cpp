#include<iostream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
class FileMode
{
public:
static int OLD;
static int NEW;
static int READ;
static int BINARY; 
};
int FileMode::OLD=1;
int FileMode::NEW=2;
int FileMode::READ=3;
int FileMode::BINARY=4; 
class OfStream
{
private:
int failed;
FILE *f;
public:
/*
OfStream(const char *fileName,int mode);
OfStream(OfStream &other,int mode);*/

void open(const char *fileName,int mode);
void write(const char *baseAddress,int size);
void operator<<(int x);
void operator<<(char x);
void operator<<(const char *x);
void close();
int fail();
};
/*OfStream::OfStream(const char *fileName,int mode)
{
this->f=NULL;
this->failed=0;
this->open(fileName,FileMode::mode);
}
OfStream::OfStream(OfStream &other,int mode)
{
this->f=NULL;
this->failed=0;
this->open(fileName,FileMode::mode);
}*/
void OfStream::open(const char *fileName,int mode)
{
if(this->f==NULL)
{
this->failed=1;
return;
}
if(mode==FileMode::NEW)
{
f=fopen(fileName,"w");
}else
{
if(mode==FileMode::OLD)
{
f=fopen(fileName,"a");
}else
{
if(mode==FileMode::BINARY | FileMode::NEW)
{
f=fopen(fileName,"wb");
}else
{
if(mode==FileMode::BINARY | FileMode::OLD)
{
f=fopen(fileName,"ab");
}
}
}
}
if(this->f==NULL)
{
this->failed==1;
}else
{
this->failed=0;
}
}

void OfStream::write(const char *baseAddress,int size)
{
if(this->f=NULL) 
{
this->failed=1;
return;
}
fwrite(baseAddress,size,1,f);
this->failed=0;
}
void OfStream::operator<<(int x)
{
if(this->f==NULL) 
{
this->failed=1;
return;
}
char a[21];
sprintf(a,"%d",x);
fputs(a,this->f);
this->failed=0;
}
void OfStream::operator<<(char x)
{
if(this->f==NULL) 
{
this->failed=1;
return;
}
fputc(x,this->f);
this->failed=0;
}
void OfStream::operator<<(const char *x)
{
if(this->f==NULL) 
{
this->failed=1;
return;
}
fputs(x,this->f);
this->failed=0;
}
int OfStream::fail()
{
return this->failed;
}
void OfStream::close()
{
if(this->f==NULL) this->failed=1;
else
{
fclose(f);
this->failed=0;
}
}

int main()
{
OfStream g;
g.open("myfile.rp",FileMode::NEW);
g<<"A";
g<<"_";
g<<"B";
g<<"\n";
g<<1234;
g<<"God is Great";
g.close();
//code for display
/*g.open("myfile.rp","r");
if(g.fail()) printf("There is no record");*/
return 0;
}