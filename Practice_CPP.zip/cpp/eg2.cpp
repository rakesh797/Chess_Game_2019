#include<iostream>
using namespace std;
int main()
{
int t[10],n;
int y,z,total;
float average_waiting_time;
cout<<"Enter the number of processing";
cin>>n;
fflush(stdin);
y=0;
while(y<n)
{
cout<<"Enter the bust time for the process"<<y+1<<":";
cin>>t[y];
y++;
}
total=0;
z=n;
y=0;
while(z>0)
{
total=total+((z-1)*t[y]);
z--;
y++;
}
cout<<"Total Waiting time is :"<<total;
average_waiting_time=total/n;
cout<<"The average waiting time is:"<<average_waiting_time;
return 0;
}