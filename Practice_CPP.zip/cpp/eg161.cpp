#include<iostream>
#include<typeinfo>
using namespace std;
class aaa
{
public:
virtual void sam(){}
};
class bbb:public aaa
{
public:
void sam(){}
};
class ccc:public aaa
{
public:
void sam(){}
};
int main()
{
aaa *a=NULL;
int ch;
cout<<"Enter your choice (1,bbb),(2,ccc):";
cin>>ch;
if(ch==1)
{
a=new bbb;
}
if(ch==2)
{
a=new ccc;
}
try
{
cout<<typeid(*a).name()<<endl;
}
catch(bad_typeid &e)
{
cout<<e.what()<<endl;
}
return 0;
}