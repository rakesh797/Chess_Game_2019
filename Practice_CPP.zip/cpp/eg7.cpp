#include<iostream>
int main()
{
int x,y,z;
std::cout<<"Enter first number:";
std::cin>>x;
std::cout<<"Enter second number:";
std::cin>>y;
z=x+y;
std::cout<<"Total is :"<<z<<std::endl;
return 0;
}