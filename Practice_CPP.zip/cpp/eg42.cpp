#include<iostream>
using namespace std;
class TV
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter price of TV";
cin>>p;
}
void printInformation()
{
cout<<"Price of TV is :"<<p<<endl;
}
friend class Utility;
};
class Fridge
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter price Fridge:";
cin>>p;
}
void printInformation()
{
cout<<"Price of Fridge is:"<<p<<endl;
}
friend class Utility;
};
class Utility
{
public:
int getTotalCost(TV &a,Fridge &b)
{
return a.p+b.p;
}
int getDifferenceInCost(TV &a,Fridge &b)
{
return (a.p<b.p)?b.p-a.p:a.p-b.p;
}
int compareCost(TV &a,Fridge &b)
{
return a.p-b.p;
}
};
int main()
{
TV t;
t.askInformation();
Fridge f;
f.askInformation();
Utility u;
cout<<"Total cost of TV and Fridge is "<<u.getTotalCost(t,f)<<endl;
if(u.compareCost(t,f)==0)
{
cout<<"Cost of Fridge and TV is same"<<endl;
}else if(u.compareCost(t,f)<0)
{
cout<<"Cost of Fridge is more than that of TV by"<<u.getDifferenceInCost(t,f)<<endl;
}else if(u.compareCost(t,f)>0)
{
cout<<"Cost of TV is more than that of Fridge by"<<u.getDifferenceInCost(t,f)<<endl;
}
return 0;
}