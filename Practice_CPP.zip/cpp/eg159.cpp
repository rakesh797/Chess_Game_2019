#include<iostream>
using namespace std;
int main()
{
int x,y,q,r;
cout<<"Enter Dividend";
cin>>x;
cout<<"Enter Diviser";
cin>>y;
try
{
if(y==0)
{
throw y;
}
q=x/y;
r=x%y;
cout<<"Quotient:"<<q<<endl;
cout<<"Remainder:"<<r<<endl;
if(r==0)
{
cout<<y<<
}
}
return 0;
}