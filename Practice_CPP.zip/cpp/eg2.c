#include<stdio.h>
int main()
{
int t[10],n;
int y,z,total;
float average_waiting_time;
printf("Enter the number of process:");
scanf("%d",&n);
fflush(stdin);
y=0;
while(y<n)
{
printf("Enter the Burst time for process %d:",(y+1));
scanf("%d",&t[y]);
y++;
}
for(y=0;y<n;y++)
{
printf("%d\n",t[y]);
}
total=0;
z=n;
y=0;
while(z>0)
{
total=total+((z-1)*t[y]);
z--;
y++;
}
printf("Total Waiting time:%d\n",total);
average_waiting_time=total/n;
printf("The average waiting time is:%f\n",average_waiting_time);
return 0;
}