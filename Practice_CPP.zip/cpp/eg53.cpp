#include<iostream>
using namespace std;
class Bulb
{
private:
int w;
public:
void intialize()
{
w=0;
}
void setWattage(int e)
{
w=e;
}
int getWattage()
{
return w;
}
};
int main()
{
Bulb g;
cout<<"Wattageis "<<g.getWattage()<<endl;
return 0;
}