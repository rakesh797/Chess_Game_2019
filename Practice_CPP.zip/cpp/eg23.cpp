#include<iostream>
using namespace std;
class Movie
{
private: 
int k;
public:
void start()
{
cout<<"Welcome"<<endl;
}
void interval()
{
cout<<"Interval-Have coffee for Rs.50/-"<<endl;
}
void end()
{
cout<<"Thank you"<<endl;
}
};
class JungleBook:private Movie
{
private:
int m;
public:
void reelOne()
{
cout<<"Bagheera finds Mongli"<<endl;
}
void reelTwo()
{
cout<<"Mogli kiss Sher Khan"<<endl;
}
};
int main()
{
JungleBook j;
cout<<"Size of object j is "<<sizeof(j)<<endl;

j.reelOne();

j.reelTwo();

return 0;
}