#include<iostream>
using namespace std;
class Rectangle
{
int length;
int breadth;
public:
void setLength(int e)
{
length=e;
}
void setBreadth(int e)
{
breadth=e;
}
int getLength()
{
return length;
}
int getBreadth()
{
return breadth;
}
};
class Box:private Rectangle
{
int height;
public:
void askInformation()
{
int e,g,h;
cout<<"Enter length :";
cin>>e;
setLength(e);
cout<<"Enter breadth:";
cin>>g;
setBreadth(g);
cout<<"Enter height:";
cin>>height;
}
void printlnformation()
{
cout<<"Length:"<<getLength()<<endl;
cout<<"Breadth:"<<getBreadth()<<endl;
cout<<"height:"<<height<<endl;
}
};
int main()
{
Box x;
x.askInformation();
x.printlnformation();
return 0;

}