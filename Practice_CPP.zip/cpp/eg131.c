#include<iostream>
using namespace std;
class Bulb
{
private:
int w;
public:
Bulb()
{
w=0;
}
Bulb(int e)
{
w=e;
}
Bulb(const Bulb &other)
{
cout<<"copy constructor got invoked"<<endl;
w=other.w;
}
void operator=(Bulb other)
{
cout<<"=funtion got envoked"<<endl;
w=other.w;
}
void setWattage(int e)
{
w=e;
}
int getWattage()
{
return w;
}
};
int main()
{
Bulb g,t,m;
g=t=m=60;
cout<<"Wattage of the bulb named as g is"<<g.getWattage()<<endl;
cout<<"Wattage of bulb named as t is "<<t.getWattage()<<endl;
cout<<"Wattage of bulb named as m is "<<m.getWattage()<<endl;
return 0;
}