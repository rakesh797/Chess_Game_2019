#include<iostream>
using namespace std;
class Bulb
{
private:
int w;
public:
void setWattage(int e)
{
w=e;
}
int getWattage()
{
return w;
}
int operator<(Bulb &right)
{
return w<right.w;
}
//more funtion to handle> <= >= == and !=
};
int main()
{
Bulb g,t;
g.setWattage(60);
t.setWattage(100);
if(g<t)
{
cout<<"Wattage of object named as g is less than that of object name as t"<<endl;
}else
{
cout<<"Wattage of object as g is not less than that of object named as t"<<endl;
}
return 0;
}