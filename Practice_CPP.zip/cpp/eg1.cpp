#include<iostream>  
using namespace std;  
class A
{
int operator+(int a,int b,A &k)
{
return a>b?a-b:b-a;
}
};
int main()  
{  
int a=10;
int b=20;
A t;
cout<<a+b+t<<endl;  
  return 0;  
} 