#include<iostream>
using namespace std;
class Node
{
int num;
Node *next,*prev;
};
Node *start=NULL;
Node *end=NULL;
class DoublyLinkList
{
public:
void addAtEnd(int);
void insertAtTop(int);
void insertAtPosition(int,int);
void removeFromPosition(int);
void traverseTopToBottom();
void traverseBottomToTop();
};

void DoublyLinkList::addAtEnd(int num)
{
Node *t,*j;
t=new Node;
t->num=num;
t->prev=NULL;
t->next=NULL;
if(start==NULL)
{
start=t;
end=t;
}
else
{
t->prev=end;
end->next=t;
end=t;
} 
}
void DoublyLinkList::insertAtTop(int num)
{
Node *t;
t=new Node;
t->num=num;
t->prev=NULL;
t->next=NULL;
if(start==NULL)
{
start=t;
end=t;
}
else
{
start->prev=t;
t->next=start;
start=t;
}
}
void DoublyLinkList::insertAtPosition(int num,int pos)
{
Node *p1;
int x;
Node *t;
t=new Node;
t->num=num;
t->prev=NULL;
t->next=NULL;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p1=p1->next;
x++;
}
if(p1==NULL)
{
if(start==NULL)
{
start=t;
end=t;
}
else
{
end->next=t;
t-prev=end;
end=t;
}
}
else
{
if(start==p1)
{
start->prev=t;
t->next=start;
start=t;
}else
{
p1->prev->next=t;
t->prev=p1->prev;
t->next=p1;
p1->prev=t;
}
}
}
void DoublyLinkList::removeFromPosition(int pos)
{
Node *p1;
int x;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p1=p1->next;
x++;
}
if(p1==NULL)
{
cout<<"Invalid position"<<endl;
}
if(p1==start && p1==end)
{
start=NULL;
end=NULL;
}else
{
if(p1==start)
{
start=start->next;
start->prev=NULL;
}else
{
if(p1==end)
{
end=end->prev;
end->next=NULL;
}else
{
p1->prev->next=p->next;
p1->next->prev=p->prev;
}
}
}
delete(p1);
}
void DoublyLinkList::traverseTopToBottom()
{
Node *t;
t=start;
while(t!=NULL)
{
cout<<t->num<<endl;
t->next;
}
}
void DoublyLinkList::traverseBottomToTop()
{
Node *t;
t=end;
while(t!=NULL)
{
cout<<t->num<<endl;
t=t->prev;
}
}
int main()
{
int ch,pos,num;
DoublyLinkList d;
while(1)
{
cout<<"1.Add node at end"<<endl;
cout<<"2.Insert node at top"<<endl;
cout<<"3.Insert nodet at position<<endl;
cout<<"4.Remove node from position<<endl;
cout<<"5.traverse top to Bottom"<<endl;
cout<<"6.traverse Bottom to Top"<<endl;
cout<<"7.Exit"<<endl;
cout<<"Enter your choice";
cin>>ch;
if(ch==1)
{
cout<<"Entert the Number:";
cin>>num;
d.addAtEnd(num);
}
if(ch==2)
{
cout<<"Entert the Number:";
cin>>num;
d.insertAtTop(num);
}
if(ch==3)
{
cout<<"Enter the number:";
cin>>num;
cout<<"Enter the position:";
cin>>pos;
d.insertAtPosition(num,pos);
}
if(ch==4)
{
cout<<"Enter the position:";
cin>>pos;
d.removFromPosition(pos);
}
if(ch==5)
{
d.traverseTopToBottom();
}
if(ch==6)
{
c.traverseBottomToTop();
}
if(ch==7)
{
break;
}
}
return 0;
}