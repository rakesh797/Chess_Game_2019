#include<stdio.h>
#include<string.h>
#include<iostream>
#include<stdio.h>
using namespace std;

class TMString
{
private:
char *str;
public:
TMString();
TMString(const char *);
TMString(const TMString &);
TMString & operator=(TMString);
TMString & operator=(const char*);
friend ostream & operator<<(ostream &out,TMString &tmString);
};

//defination of methods
TMString::TMString()
{
this->str=NULL;
}

TMString::TMString(const char *str)
{
if(str==NULL || *str=='\0')
{
this->str=NULL;
}
else
{
this->str=new char[strlen(str)+1];
strcpy(this->str,str);
}

TMString::TMString(const TMString &other)
{
if(other.str==NULL)
{
this->str=NULL;
}
else
{
this->str=new char[strlen(other.str)+1];
strcpy(this->str,other.str);
}
}

TMString & TMString::operator=(TMString other)
{
if(this->str!=NULL) delete [] (this->str);
if(other.str==NULL) this->str=NULL;
else
{
this->str=new char[strlen(other.str)+1];
strcpy(this->str,other.str);
}
return *this;
}

TMString & TMString::operator=(const char *str)
{
if(this->str!=NULL) delete [] (this->str);
if(other.str==NULL) this->str=NULL;
else
{
this->str=new char[strlen(other.str)+1];
strcpy(this->str,other.str);
}
return *this;
}
ostream & operator<<(ostream &out,TMString &tmString)
{
if(tmString.str!=NULL) out<<tmstring.str;
return out;
}
int main()
{
TMString s;
s="Hello";
cout<<s<<endl;
TMString s="Good";
TMString k;
k=b;
cout<<k<<endl;
TMString r,d;
r=k=d="Morning";
cout<<r<<","<<k<<","<<d<<endl;
return 0;
}