#include<iostream>
using namespace std;
int main()
{
int x,y,q,r;
cout<<"Enter the Dividend:";
cin>>x;
cout<<"Enter the Divisor:";
cin>>y;
if(y!=0)
{
q=x/y;
r=x%y;
cout<<"Quotient :"<<q<<endl;
cout<<"Remainder :"<<r<<endl;
if(r==0)
{
cout<<y<< "is the factor of" <<x<<endl;
cout<<x<<"x"<<y<<"="<<x<<endl;
}else
{
cout<<y<< "is not the factor of" <<x<<endl;
cout<<x<<"x"<<y<<"+"<<r<<"="<<x<<endl;
}
}else
{
cout<<"Divisor cannot be"<<y<<endl;
}
return 0;
}