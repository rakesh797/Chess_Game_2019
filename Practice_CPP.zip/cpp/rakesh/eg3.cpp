#include<iostream>
class ram
{
void tom()
{
cout<<"tam tam bum bum"<<endl;
}
}
namespace ramu
{
ram r;
}
int main()
{
r.tom();
return 0;
}