#include<iostream>
#include<string.h>
#include<stdlib.h>
class File
{
public:
FILE *k;
public:
static int NEW;
static int ADD;
static int READ;
public:
File(char *fileName,int e)
{
if(e==1)
{
k=fopen(fileName,"wb");
}
if(e==2)
{
k=fopen(fileName,"ab");
}
if(e==3)
{
k=fopen(fileName,"rb");
}
}
void fopen(char *fileName,int e)
{
if(e==1)
{
k=fopen(fileName,"w");
}
if(e==2)
{
k=fopen(fileName,"a");
}
if(e==3)
{
k=fopen(fileName,"r");
}
}
File & operator<<(int e)
{
char a[11];
sprintf(a,x);
fputs(a,k);
fputs("\n",k);
return *this;
} 
File & operator<<(char *e)
{
fputs(e,k);
fputs("\n",k);
return *this;
}
File & operator<<(char e)
{
fputc(e,k);
fputs("\n",k);
return *this;
}
void close()
{
fclose(k);
}
};
namespace io
{
File f;
}
using namepace io;
int File::NEW=1;
int File::ADD=2;
int File::READ=3;
int main()
{
File f=("whatever.xyz",File::NEW);
f<<102;
f<<"rahul";
f<<'M';
f.close();
return 0;
}