#include<iostream>
using namespace std;
class Car
{
};
class MarutiALTO:public Car
{
// some 1000 properties
public:
void manual()
{
cout<<"Blah blah blah about Maruti ALTO"<<endl;
}
// many more methods
};
class HondaCity:public Car
{
// some 1500 properties
public:
void manual()
{
cout<<"Blah blah blah about Honda City"<<endl;
}
// many more methods
};
int main()
{
int ch;
Car *c;
cout<<"1. Maruti ALTO"<<endl;
cout<<"2. Honda City"<<endl;
cout<<"Enter your choice :";
cin>>ch;
if(ch>=1 && ch<=2)
{
if(ch==1)
{
c= new MarutiALTO;
}
if(ch==2)
{
c=new HondaCity;
}
c->manual();
}
else
{
cout<<"Invalid choice"<<endl;
}
return 0;
}