#include<iostream>
using namespace std;
class LinkListNode
{
private:
int data;
LinkListNode *prev;
LinkListNode *next;
friend class LinkList;
LinkListNode(int data)
{
this->data=data;
this->next=NULL;
this->prev=NULL;
}
};
class LinkList
{
private:
LinkListNode *start;
LinkListNode *end;
int size=0;
public:
LinkList();
LinkList(const LinkList &);
LinkList & operator=(LinkList);
int operator[](int);
void add(int);
int getData(int);
int getSize();
void removeAll();
int removeNode(int);
};
LinkList::LinkList()
{
start=NULL;
end=NULL;
}
LinkList::LinkList(const LinkList &other)
{
this->start=NULL;
this->end=NULL;
LinkListNode *t;
t=other.start;
while(t!=NULL)
{
this->add(t->data);
t=t->next;
}
}
LinkList & LinkList::operator=(LinkList other)
{
removeAll();
this->start=NULL;
this->end=NULL;
LinkListNode *t;
t=other.start;
while(t!=NULL)
{
this->add(t->data);
t=t->next;
}
}
int LinkList::operator[](int index)
{
if(index<0 || index>size) return 0;
int x=1;
LinkListNode *t;
t=this->start;
while(x<=index)
{
t=t->next;
x++;
}
return t->data; 
}
void LinkList::add(int data)
{
LinkListNode *t;
t=new LinkListNode(data);
if(this->start==NULL)
{
this->start=t;
this->end=t;
}else
{
this->end->next=t;
t->prev=this->end;
this->end=t;
}
size++;
}
int LinkList::getData(int index)
{
if(index<0 || index>=this->size)
{
return 0;
}
LinkListNode *t;
int x=1;
t=this->start;
while(x<=index)
{
t=t->next;
x++;
}
return t->data;
}
int LinkList::getSize()
{
return this->size;
}
void LinkList::removeAll()
{
LinkListNode *t;
while(this->start!=NULL)
{
t=this->start;
this->start=this->start->next;
delete t;
}
size=0;
}
int LinkList::removeNode(int index)
{
if(index<0 || index>=size)
{
return 0;
}
int x;
x=1;
LinkListNode *p1,*p2;
p1=this->start;
while(x<=index && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1==this->start && p1==this->end)
{
this->start=NULL;
this->end=NULL;
}else
{
if(p1==this->start)
{
this->start=this->start->next;
this->start->prev=NULL;
}else
{
if(p1==this->end)
{
this->end=p1->prev;
this->end->next=NULL;
}else
{
p2->next=p1->next;
p1->next->prev=p2;
}
}
}
size--;
return p1->data;
}
int main()
{
LinkList list;
list.add(20);
list.add(30);
list.add(40); 
int e;
cout<<list.getSize()<<endl;
for(e=0;e<list.getSize();e++)
{
cout<<list[e]<<endl;
}
return 0;
}