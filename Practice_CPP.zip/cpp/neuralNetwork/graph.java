2017-08 2017-12  
C and C++ programming Course

2018-01 2018-05  
Java core and advance programming Course

2018-07 2018-11  
Machine Learning