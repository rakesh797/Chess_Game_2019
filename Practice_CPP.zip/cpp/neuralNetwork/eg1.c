#include<stdio.h>
void main(int i=10)
{
while(i--)
{
if(printf("%d",i)
{

}
}
}