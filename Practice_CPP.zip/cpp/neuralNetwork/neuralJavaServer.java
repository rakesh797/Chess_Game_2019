import java.io.*;
import java.net.*;
import java.awt.*;
import javax.swing.*;
/*class Graph
{
private Map<Double,Double> points=new HashMap<>();
Graph(double x,double y)
{
points.add(x,y);
}
public void paint(Graphics graphic)
{

}
}*/
class ChotaServer
{
private ServerSocket serverSocket;
private int portNumber;
ChotaServer(int portNumber)
{
this.portNumber=portNumber;
try
{
serverSocket=new ServerSocket(this.portNumber);
startListening();
}catch(Exception e)
{
System.out.println(e);
System.exit(0);
}
}
public void startListening()
{
try
{
Socket ck;
while(true)
{
System.out.println("Server is listening on port : "+this.portNumber);
ck=serverSocket.accept();
System.out.println("Request arrived");
new RequestProcessor(ck);
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String data[])
{
int portNumber=Integer.parseInt(data[0]);
ChotaServer cs=new ChotaServer(portNumber);
}
}
class RequestProcessor extends Thread
{
private Socket ck;
RequestProcessor(Socket socket)
{
this.ck=socket;
start();
}
public void run()
{
try
{
InputStream is;
InputStreamReader isr;
OutputStream os;
OutputStreamWriter osw;
StringBuffer sb;
String request;
int x;
int c1,c2;
String p1,p2,pc3;
int rollNumber;
String name;
String gender;
String response;
is=ck.getInputStream();
isr=new InputStreamReader(is);
sb=new StringBuffer();
while(true)
{
x=isr.read();
if(x=='#')
{
break;
}
sb.append((char)x);
}
request=sb.toString();
System.out.println("Request :"+request);
c1=request.indexOf(",");
p1=request.substring(0,c1);
p2=request.substring(c1+1);
System.out.println("Coordinates : "+p1+","+p2);
ck.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}