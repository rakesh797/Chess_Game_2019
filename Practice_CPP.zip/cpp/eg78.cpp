#include<iostream>
using namespace std;
int main()
{
int x;
x=41;
cout<<x<<endl;
x=041;
cout<<x<<endl;
x=0x41;
cout<<x<<endl;
x=0b100001;
cout<<x<<endl;
return 0;
}