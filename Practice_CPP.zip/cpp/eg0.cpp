#include<iostream>
using namespace std;
class Node
{
public:
int num;
Node *next;
};
Node *start=NULL;
class Singly_link_list
{
public:
void addAtEnd(int num)
{
Node *t,*j;
t=new Node;
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
j=start;
while(j->next!=NULL)
{
j=j->next;
}
j->next=t;
}
}
void insertAtTop(int num)
{
Node *t;
t=new Node;
t->num=num;
t->next=NULL;
if(start==NULL)
{
start=t;
}
else
{
t->next=start;
start=t;
}
}
void insertAtPosition(int num,int pos)
{
Node *p1,*p2;
int x;
Node *t;
t=new Node;
t->num=num;
t->next=NULL;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1==NULL)
{
if(start==NULL)
{
start=NULL;
}
else
{
p2->next=t;
}
}
else
{
if(p1==start)
{
t->next=start;
start=t;
}
else
{
t->next=p1;
p2->next=t;
}
}
}
void removeFromPosition(int pos)
{
Node *p1,*p2;
int x;
x=1;
p1=start;
while(x<pos && p1!=NULL)
{
p2=p1;
p1=p1->next;
x++;
}
if(p1==NULL)
{
cout<<"Invalid position"<<endl;
return;
}
if(p1==start)
{
start=start->next;
}
else
{
p2->next=p1->next;
}
delete(p1);
}
void traverseTopToBottom()
{
Node *t;
t=start;
while(t!=NULL)
{
cout<<t->num<<endl;
t=t->next;
}
}
void traverseBottomToTop(Node *t)
{
if(t==NULL)
{
return;
}
else
{
traverseBottomToTop(t->next);
cout<<t->num<<endl;
}
}
};
int main()
{
int ch,num,pos;
Singly_link_list s;
while(1)
{
cout<<"1.Add the node at end"<<endl;
cout<<"2.Insert the node at top"<<endl;
cout<<"3.Insert the node at position"<<endl;
cout<<"4.Remove the node at Position"<<endl;
cout<<"5.Traverse-top to Bottom"<<endl;
cout<<"6.Traverse-Bottom to top"<<endl;
cout<<"7.Exit"<<endl;
cout<<"Enter your choice:";
cin>>ch;
if(ch==1)
{
cout<<"Enter the number:";
cin>>num;
s.addAtEnd(num);
}
if(ch==2)
{
cout<<"Enter the number:";
cin>>num;
s.insertAtTop(num);
}
if(ch==3)
{
cout<<"Enter the number:";
cin>>num;
cout<<"Enter the position:";
cin>>pos;
s.insertAtPosition(num,pos);
}
if(ch==4)
{
cout<<"Enter the position";
cin>>pos;
s.removeFromPosition(pos);
}
if(ch==5)
{
s.traverseTopToBottom();
}
if(ch==6)
{
s.traverseBottomToTop(start);
}
if(ch==7)
{
break;
}
}
return 0;
}