#include<iostream>
using namespace std;
template<class whatever>
class Stack
{
private:
whatever stack[100];
int lowerBound;
int upperBound;
int top;
public:
Stack();
int isEmpty();
int isFull();
void push(whatever);
whatever pop();
};
template<class whatever>
Stack<whatever>::Stack()
{
lowerBound=0;
UpperBound=99;
top=100;
} 
template<class whatever>
int Stack<whatever>::isEmpty()
{
return top==upperBound+1;
}
template<class whatever>
int Stack<whatever>::isFull()
{
return top==lowerBound;
}
template<class whatever>
void Stack<whatever>::push(whatever data)
{
if(isFull()) return;
top--;
stack[top]=data;
}
template<class whatever>
whatever Stack<whatever>::pop()
{
whatever data;
if(isEmpty()) return 0;
data=stack[top];
top++;
return data;
}
int main()
{
Stack<int>s1;
Stack<float>s2;
s1.push(10);
s1.push(20);
s1.push(30);
s1.push(40);
s2.push(100.2f);
s2.push(200.3f);
s2.push(300.4f);
while(!s1.isEmpty())
{
cout<<s1.pop()<<endl;
}
while(!s2.isEmpty())
{
cout<<s2.pop()<endl;
}
return 0;
}