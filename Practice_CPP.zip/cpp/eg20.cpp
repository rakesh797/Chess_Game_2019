#include<iostream>
using namespace std;
class Rectangle
{
int length;
int breadth;
public:
void setLength(int e)
{
length=e;
}
void setBreadth(int e)
{
breadth=e;
}
int getLength()
{
return length;
}
int getBreadth
{
return breadth;
}
};
class Box:private Rectangle
{
int height;
public:
void setHeight()
{
height=e;
}
int getHeight()
{
return height;
}
};
int main()
{
Box x;
x.length=10;
x.breadth=3;
x.height=40;
}