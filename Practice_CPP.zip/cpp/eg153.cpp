#include<stdio.h>
#include<iostream>
#include<stdlib.h>
using namespace std;
#define true 1
#define false 0
#define TRUE 1
#define FALSE 0
class TMFileMode
{
private:
TMFileMode()
{
}
public:
static short append;
static short out;
static short in;
static short binary;
};
short TMFileMode::append=1;
short TMFileMode::out=2;
short TMFileMode::in=4;
short TMFileMode::binary=8;
class TMOutputFileStream
{
FILE *f;
int failed;
public:
TMOutputFileStream(const char *fileName)
{
this->failed=false;
this->f=NULL;
this->open(fileName,TMFileMode::out);
}
TMOutputFileStream(const char *fileName,short fileMode)
{
this->failed=false;
this->f=NULL;
this->open(const char *fileName,short fileMode)
{
if(this->f!=NULL)
{
this->failed=true;
return;
}
if(fileMode==TMFileMode::out)
{
this->f=open(fileName,"w");
}else if(fileMode==TMFileMode::append)
{
this->f=open(fileName,"a");
}else if(fileMode==(TMFileMode::append | TMFileMode::binary))
{
this->f=open(fileName,"ab");
}
if(f!=NULL) this->failed=false: else this->failed=true;
}
int hasOperationFailed()
{
return this->failed;
}
void close()
{
if(this->f==NULL) this->failed=true;
else
{
fclose(f);
this->failed=false;
}
}
void operator<<(int x)
{
if(this->NULL)
{
this->failed=true;
return;
}
char data[21];
sprintf(data,"%d",x);
fputs(data,this->f);
this->failed=false;
}
void operator<<(char x)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
fputc(x,this->f);
this->failed=false;
}
void operator<<(const char *x)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
fputs(x,this->f);
this->failed=false;
}
void writeBytes(const char *baseAddress,int size)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
fwrite(baseAddress,size,1,f);
this->failed=false;
}
};
class TMInputFileStream
{
FILE *f;
int failed;
public:
TMInputFileStream(const char *fileName)
{
this->failed=false;
this->f=NULL;
this->open(fileName,TMFileMode::in);
}
TMInputFileStream(const char *fileName,short fileMode)
{
this->failed=false;
this->f=NULL;
this->open(fileName,fileMode);
}
void open(const char *fileName,short fileMode)
{
if(this->f=NULL)
{
this->failed=true;
return;
}
if(fileMode==TMfileMode::in)
{
this->f=fopen(fileNmae,"rb");
}
if(f!=NULL) this->failed=false: else this->failed=true;
}
int hasOperationFailed()
{
return this->failed;
}
void close()
{
if(this->f=NULL) this->failed=true;
else
{
fclose(f);
this->failed=false;
}
}
void operator>>(int &x)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
if(feof(this->f))
{
x=0;
this->failed=true;
return;
}
char data[21];
char m;
int i;
i=0;
while(1)
{
m=fgetc(this->f);
if(feof(this->f)) break;
if(m==' ') break;
data[i]='\0';
x=atoi(data);
this->failed=false;
}
void operator>>(char &x)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
if(feof(this->f))
{
x=0;
this->failed=true;
return;
}
x=fgets(this->f);
if(x==EOF)
{
x=0;
this->failed=true;
return;
}
this->failed=false;
}
void operator>>(char *x)
{
if(this->f==NULL)
{
this->failed=true;
return;
}
if(feof(this->f)
{
*x='\0';

}
}
}
}