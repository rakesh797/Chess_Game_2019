#include <iostream>  
using namespace std;  
  
class Date  
{ 
public: 
    int mo, da, yr;  
    friend ostream& operator<<(ostream& os, const Date& dt);  
};  
  
ostream& operator<<(ostream& s, const Date& dt)  
{  
    s<<dt.mo;
return s; 
}  
  
int main()  
{  
    Date dt,kk;
dt.mo=5;  
kk.mo=6;
    cout << dt<<kk;  
}  
