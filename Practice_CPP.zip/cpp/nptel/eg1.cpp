#include<iostream>
using namespace std;
class MyType
{
public:
int a;
/*public:
MyType* operator+(const MyType &other)
{
this->a=this->a+other.a;
return this; 
}
MyType* operator++()
{
this->a++;
return this;
}
MyType* operator++(int)
{
this->a++;
return this;
}
int &operator[](const MyType &other)
{
//cout<<other.a<<endl;
}*/
friend ostream& operator<<(ostream s,const MyType &other);
};
ostream& operator<<(ostream s,const MyType &other)
{
s<<other.a;
return s;
}
int main()
{
MyType t,r,q;
t.a=50;
cout<<t;
return 0;

}