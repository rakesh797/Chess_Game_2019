interface aaaa
{
aaa();
}
class aaa implements aaaa
{
public int w;
public aaa()
{
System.out.println("default contructor");
w=1;
}
public aaa(int x)
{
System.out.println("parameterized contructor");
}
}
class test1
{
public static void main(String gg[])
{
aaa a=new aaa(12);
}
}
