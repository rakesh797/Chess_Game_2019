// detach
#include<iostream>
#include<stdio.h>
#include<thread>
using namespace std;
using namespace this_thread;
int count=100;

class DisplayThread
{
public:
void operator()()
{
for(int i=0;i<10000;i++)
printf("Thread is running %d\n",i);
}
};
int main()
{
thread threadObj((DisplayThread()));
//threadObj.join();
for(int i=0;i<1000;i++)
{
if(count==i) threadObj.detach();
}
cout<<"Waiting for thread to finish"<<endl;
cout<<"Main thread ends"<<endl;
return 0;
}