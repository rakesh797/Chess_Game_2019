//Creating a thread using Lambda functions
#include<iostream>
#include<thread>
using namespace std;
int main()
{
int x=9;
thread threadObj([]{
for(int i=0;i<1000;i++)
  cout<<"Display Thread Executing"<<endl;
});
for(int j=0;j<200;j++)
cout<<"Display From Main Thread"<<endl;
threadObj.join();
cout<<"Existing from Main Thread"<<endl;
return 0;
}