#include<iostream>
#include<thread>
using namespace std;

void thread_function()
{
for(int i=0;i<10;i++)
{
std::cout<<"thread function Executing"<<i<<endl;
}
}
int main()
{
int a;
thread threadObj(thread_function);
for(int i=0;i<100;i++)
{
cout<<"Display from MainThread"<<i<<endl;
}
threadObj.join();
cout<<"Exit of Main function"<<endl;
return 0;
}