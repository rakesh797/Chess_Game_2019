//joining threads with std::thread::join()
#include<iostream>
#include<stdio.h>
#include<thread>
#include<algorithm>
#include<vector>
#include<functional>
using namespace std;
using namespace this_thread;
class WorkerThread
{
public:
void operator()()
{
printf("Worker Thread %d is Executing\n",get_id());
}
};
int main()
{
vector<thread> threadList;
for(int i=0;i<10;i++)
{
threadList.push_back(thread(WorkerThread()));
}
cout<<"wait for all the worker thread to finish\n"<<endl;
//std::for_each(threadList.begin(),threadList.end(), std::mem_fn(&std::thread::join));
/*vector<thread>::iterator itr=threadList.begin();
thread t;
while(itr!=threadList.end())
{
t=itr;
t.join();
++itr;
}*/
cout<<"Exiting from Main Thread"<<endl;
return 0;
}