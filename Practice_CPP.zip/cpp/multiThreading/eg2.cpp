//Creating a thread using Function Objects
#include<iostream>
#include<stdio.h>
#include<thread>
using namespace std;
class DisplayThread
{
public:
void operator()()
{
for(int i=0;i<100;i++)
{
this->sam();
}
}
void sam()
{
printf("This is cool\n");
}
};
int main()
{
DisplayThread dt;
thread threadObj((DisplayThread()));
for(int i=0;i<1000;i++)
{
printf("Display From Main Thread\n");
}
cout<<"Waiting for thread to complete"<<endl;
threadObj.join();
cout<<"Exiting from Main Thread"<<endl;
return 0;
}
