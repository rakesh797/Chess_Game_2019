//
#include<iostream>
#include<thread>
using namespace std;
using namespace this_thread;
void thread_function()
{
cout<<"Inside Thread : :ID="<<get_id()<<endl;
}
int main()
{
thread threadObj1(thread_function);
thread threadObj2(thread_function);
if(threadObj1.get_id()!=threadObj2.get_id())
{
cout<<"Both Threads have different IDs "<<endl;
}
cout<<"From main thread ID of the thread1="<<threadObj1.get_id()<<endl;
cout<<"From Main thread ID of the thread 2 ="<<threadObj2.get_id()<<endl;
threadObj1.join();
threadObj2.join();
return 0;
}