
class aaa
{
private:
int x;
protected:
int y;
public:
int z;
};
class bbb:protected aaa
{

};
class ccc:public bbb
{
public:
void sam()
{
y=20;
z=30;
}
};
class ddd:private aaa
{

};
class eee:public ddd
{
public:
void tom()
{
y=20;
z=30;
}
};
int main()
{
return 0;
};