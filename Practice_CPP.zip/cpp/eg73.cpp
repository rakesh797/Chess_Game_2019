#include<iostream>
using namespace std;
int main()
{
int j;
j=60;
int *p;
p=new int;
*p=100;
cout<<*p<<endl;
return 0;
}