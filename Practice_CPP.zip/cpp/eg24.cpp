#include<iostream>
using namespace std;
class Movie
{
public:
void start()
{
cout<<"Welcome"<<endl;
}
void interval()
{
cout<<"Interval-have coffee at Rs.50/-"<<endl;
}
void end()
{
cout<<"Thank YOU"<<endl;
}
};
class JungleBook:public Movie
{
public:
void interval()
{
cout<<"Interval-Have coffee in Rs.25/-"<<endl;
}
void reelOne()
{
cout<<"Bagheera finds Mowgli"<<endl;
}
void reelTwo()
{
cout<<"Mowgli kills SherKhan"<<endl;
}
};
int main()
{
JungleBook j;
cout<<"Size of object is "<<sizeof(j)<<endl;
j.start();
j.reelOne();
j.interval();
j.reelTwo();
j.end();
return 0;
}