#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;
class TMString
{
private:
char *str;
public:
TMString();
TMString(const char *);
TMString(const TMString &);
TMString & operator=(TMString);
TMString & operator=(const char *);
friend ostream & operator<<(ostream &out,TMString &tmString);
~TMString();
TMString operator+(const char *);
TMString operator+(TMString &);
};
TMString::TMString()
{
this->str=NULL;
}
TMString::~TMString()
{
if(this->str!=NULL) delete [] (this->str);
}
TMString::TMString(const char *str)
{
if(str==NULL || *str=='\0') this->str=NULL;
else
{
this->str=new char[strlen(str)+1];
strcpy(this->str,str);
}
}

TMString::TMString(const TMString &other)
{
if(other.str==NULL) this->str=NULL;
else
{
this->str=new char[strlen(other.str)+1];
strcpy(this->str,other.str);
}
}

TMString & TMString::operator=(TMString other)
{
if(this->str!=NULL) delete [] (this->str);
if(other.str==NULL) this->str=NULL;
else
{
this->str=new char[strlen(other.str)+1];
strcpy(this->str,other.str);
}
return *this;
}

TMString & TMString::operator=(const char *str)
{
if(this->str!=NULL) delete [] (this->str);
if(str==NULL || *str=='\0') this->str=NULL;
else
{
this->str=new char[strlen(str)+1];
strcpy(this->str,str);
}
return *this;
}
// Complete the following code
TMString TMString::operator+(const char *str)
{
TMString *t;
if(this->str==NULL)
{
return TMString(this->str);
}
else
{
t->str=new char[strlen(this->str)+strlen(str)+1];
strcpy(t->str,this->str);
strcat(t->str,str);
return (t->str);
}
}
TMString TMString::operator+(TMString &other)
{
TMString *t;
if(other.str==NULL)
{
return TMString(this->str);
}
else
{
t->str=new char[strlen(other.str)+strlen(this->str)+1];
strcpy(t->str,this->str);
strcat(t->str,other.str);
return (t->str);
}
}

ostream & operator<<(ostream &out,TMString &tmString)
{
if(tmString.str!=NULL) out<<tmString.str;
return out;
}

int main()
{
TMString a;
a="Great";
cout<<a<<endl;
TMString b="Good";
TMString k;
k=b;
cout<<k<<endl;
TMString r,d;
r=k=d="Ujjain";
cout<<r<<","<<k<<","<<d<<endl;
cout<<"--------------------------------------------------"<<endl;
b=a+" & Cool";
r=d+a;
cout<<b<<endl;
cout<<r<<endl;
return 0;
}