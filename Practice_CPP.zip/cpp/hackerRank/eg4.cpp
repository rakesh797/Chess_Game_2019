#include <iostream>
#include<stdio.h>
#include <deque> 
using namespace std;

void printKMax(int arr[], int n, int k){
	//Write your code here.
    deque<int> d;
    for(int i=0;i<n;i++)
    {
d.push_back(arr[i]);
    }
    int max,tmp;
    int i=0;
    int f=d.size()-k+1;
    while(i<f)
    {
        
        
        max=d[0];
        for(int j=1;j<=k-1;++j)
        {
               if(max<d[j]) max=d[j];
        }
       printf("%d ",max);
       ++i;
       d.pop_front();
        
    }
    printf("\n");
}

int main(){
  
	int t;
	cin >> t;
	while(t>0) {
		int n,k;
    	scanf("%d %d",&n,&k);
    	int i;
    	int arr[n];
    	for(i=0;i<n;i++)
      		scanf("%d",&arr[i]);
    	printKMax(arr, n, k);
    	t--;
  	}
  	return 0;
}
