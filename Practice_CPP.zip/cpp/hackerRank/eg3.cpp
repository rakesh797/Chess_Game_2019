#include <iostream>
#include<stdio.h>
#include <deque> 
using namespace std;

void printKMax(int arr[], int n, int k){
	//Write your code here.
int low=0;
int high=k-1;

    
}

int main(){
  
	int t;
	cin >> t;
	while(t>0) {
		int n,k;
    	scanf("%d %d",&n,&k);
    	int i;
    	int arr[n];
    	for(i=0;i<n;i++)
      		scanf("%d",&arr[i]);
    	printKMax(arr, n, k);
    	t--;
  	}
  	return 0;
}
