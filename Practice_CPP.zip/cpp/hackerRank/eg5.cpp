#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
double A=100.345;
double B=2006.008;
double C=2331.41592653498;
cout << hex << left << showbase << nouppercase;
cout<<(long long )A<<endl;
cout<<dec<<right<<setw(15)<<setfill('_')<<showpos<<fixed<<setprecision(2);
cout<<B<<endl;
cout<<scientific<<setprecision(9)<<noshowpos<<uppercase<<C<<endl;
return 0;
}