#include<iostream>
using namespace std;
class aaa
{
public:
void sam()
{
cout<<"Ujjain"<<endl;
}
static void tom()
{
cout<<"Indore"<<endl;
}
};
int main()
{
aaa::sam();
aaa::tom();
aaa a;
a.sam();
a.tom();
return 0;
}