#include<iostream>
class File
{

};

using namespace io;
int main()
{
File f("whatever.txt",File::NEW); // File::ADD
f<<102<<"mahesh";
f<<"illusion";
f<<'M';
fclose();
return 0;
}