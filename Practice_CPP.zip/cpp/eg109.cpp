#include<iostream>
using namespace std;
class aaa
{
public:
aaa()
{
cout<<"Default Contructor"<<endl;
}
~aaa()
{
cout<<"Destructor"<<endl;
}
};
void lmn()
{
aaa a,b,c;
cout<<"Ujjain"<<endl;
}
int main()
{
aaa p,q;
cout<<"Indore"<<endl;
lmn();
cout<<"Dewas"<<endl;
return 0;
}