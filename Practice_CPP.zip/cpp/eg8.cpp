#include<iostream>
using namespace std;
int main()
{
int x,y,z;
cout<<"Enter the first number:";
cin>>x;
cout<<"Enter the second number:";
cin>>y;
z=x+y;
cout<<"Total is :"<<z;
return 0;
}