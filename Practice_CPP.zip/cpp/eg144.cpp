#include<iostream>
using namespace std;
int main()
{
int x,y;
x=10;
x++;
y=20;
++y;
cout<<x<<endl;
cout<<y<<endl;
int z;
z=x++;
cout<<x<<endl;
cout<<z<<endl;
int p;
p=++y;
cout<<y<<endl;
cout<<p<<endl;
return 0;
}