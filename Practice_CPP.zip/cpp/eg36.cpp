#include<iostream>
using namespace std;
int main()
{
int x;
int &y=x;
y=20;
cout<<x<<endl;
cout<<y<<endl;
x=100;
cout<<x<<endl;
cout<<y<<endl;
return 0;
}