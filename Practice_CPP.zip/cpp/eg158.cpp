#include<iostream>
using namespace std;
int main()
{
int y,x,q,r;
cout<<"Enter the Dividend:";
cin>>x;
cout<<"Enter the Divisor:";
cin>>y;
try
{
if(y==0)
{
return y;
}
q=x/y;
r=x%y;
cout<<"Quotient :"<<q<<endl;
cout<<"Divisor :"<<r<<endl;
if(r==0)
{
cout<<y<<" is factor of "<<x<<endl;
cout<<y<<" x" <<q<<"="<<x<<endl;
}
else
{
cout<<y<<"is not the factor of "<<x<<endl;
cout<<y<<"x"<<q<<"+"<<r<<"="<<x<<endl;
}
}catch(int e)
{
cout<<"Divisor connot be :"<<e<<endl;
}
return 0;
}