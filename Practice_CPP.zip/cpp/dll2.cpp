class IfStream
{
private:
int fail;
FILE *f;
public:

/*OfStream(const char *fileName,int mode);
OfStream(OfStream &other,int mode);*/

void fopen(const char *fileName,int mode);
void read(const char &baseAddress,int size);
void operator<<(int &x);
void operator<<(char &x);
void operator<<(const char &x);
void close();
int fail();
};
/*OfStream::OfStream(const char *fileName,int mode)
{
this->f=NULL;
this->fail=0;
this->open(fileName,mode);
}
IfStream::IfStream(IfStream &other,int mode)
{
this->f=NULL;
this->fail=0;
this->open(fileName,mode);
}*/
void IfStream::open(const char *fileName,int mode)
{
if(this->f==NULL)
{
this->fail=1;
return;
}
if(mode==fileMode::READ)
{
f=fopen(fileName,"r");
}
else if(mode==(fileMode::READ | fileMode::BINARY));
{
f=fopen(fileName,"rb");
}
if(this->f==NULL)
{
this->fail==1;
}else
{
this->fail=0;
}
}

void IfStream::read(const char &baseAddress,int size)
{
if(this->f=NULL) 
{
this->fail=1;
return;
}
if(feof(f)) break;
fread(baseAddress,size,1,f);
if(feof(f)) this->fail=1;
this->fail=0;
}
void IfStream::operator>>(int &x)
{
if(this->f==NULL) 
{
this->fail=1;
return;
}
if(feof(f)) 
{
this->fail=1;
return;
}
char a[21];
char m;
int i=0;
while(1)
{
m=fgetc(f)
if(feof(f)) break;
if(m==' ') break;
a[i]=m;
i++;
}
a[i]='\0';
x=atoi(a);
this->failed=false;
}
void IfStream::operator>>(char &x)
{
if(this->f==NULL) 
{
this->fail=1;
return;
}
if(feof(f)) 
{
this->fail=1;
return;
}
fgetc(x,this->f);
this->fail=0;
}
void IfStream::operator>>(const char &x)
{
if(this->f==NULL) 
{
this->fail=1;
return;
}
if(feof(f)) 
{
this->fail=1;
break;
}
fgets(x,f);
if(feof(f))
{
this->fail=1;
break;
}
this->fail=0;
}
int IfStream::fail()
{
return this->fail;
}
void IfStream::close()
{
if(this->f==NULL) this->fail=1;
else
{
fclose(f);
this->fail=0;
}
}