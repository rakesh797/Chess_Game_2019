#include<iostream>
using namespace std;
class Matrix
{
private:
	int numberOfRow;
	int numberOfColumn;
	int *arr;
public:
	Matrix(int);
	Matrix(int ,int);
	Matrix & operator=(Matrix &);
	/*
	void operator+(Matrix&);
	Matrix & operator+(Matrix&);
	void operator-(Matrix&);
	Matrix & operator-(Matrix&);
	void operator*(Matrix&);
	Matrix & operator*(Matrix&);
	*/


	
	
	void setValue(int,int,int);
	int getValue(int,int);
	void print();

	~Matrix();

	
};

Matrix::Matrix(int size)
{
	// Square matrix case
	this->numberOfRow=size;
	this->numberOfColumn=size;
	arr=new int[size*size];
	
}

Matrix::Matrix(int rowSize,int columnSize)
{
	this->numberOfRow=rowSize;
	this->numberOfColumn=columnSize;
	arr=new int[numberOfRow*numberOfColumn];
	
}

void Matrix::setValue(int rowIndex,int colIndex,int value)
{
*(arr+4*(numberOfRow*rowIndex+colIndex))=value;
cout<<getValue(rowIndex,colIndex)<<endl;
}
int Matrix::getValue(int rowIndex,int colIndex)
{
	
	return *(arr+4*(numberOfRow*rowIndex+colIndex));
	
}

void Matrix::print()
{
	for(int i=0;i<numberOfRow;++i)
	{
		for(int j=0;j<numberOfColumn;++j)
		{

			cout<<"="<<getValue(0,3)<<"index("<<i<<","<<j<<")= "<<getValue(i,j)<<"  ";
		}
		cout<<""<<endl;
		cout<<endl;
	}
}

Matrix& Matrix::operator=(Matrix &other)
{
	for(int i=0;i<numberOfRow;++i)
	{
		for(int j=0;j<numberOfColumn;++j)
		{
 			setValue(i,j,other.getValue(i,j));
		}
	}
	return *this;
}

Matrix::~Matrix()
{
	//delete [] arr;
}


int main()
{
	Matrix matrix(3,4);
	matrix.setValue(0,0,1);
	matrix.setValue(0,1,2);
	matrix.setValue(0,2,3);
	matrix.setValue(0,3,4);
cout<<"hiii"<<endl;
	matrix.setValue(1,0,5);
cout<<"hiii1"<<endl;
	matrix.setValue(1,1,6);
cout<<"hiii2"<<endl;
	matrix.setValue(1,2,7);
cout<<"hiii3"<<endl;
	matrix.setValue(1,3,8);
cout<<"hiii4"<<endl;
		matrix.setValue(2,0,9);
	matrix.setValue(2,1,10);
	matrix.setValue(2,2,11);
	matrix.setValue(2,3,12);
	
	matrix.print();
	Matrix matrix2(3,4);
	matrix2=matrix;
	matrix2.print();

	return 0;
}