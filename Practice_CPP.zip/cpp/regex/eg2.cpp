#include<regex>
#include<iostream>
using namespace std;
int main()
{
string s="My name is Rakesh Patidar";
regex r("Rakesh[a-zA-Z]+");
smatch m;
regex_search(s,m,r);
for(auto x:m)
 cout<<x<<" ";
return 0;
}