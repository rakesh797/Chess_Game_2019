#include<iostream>
#include<regex>
using namespace std;
int main()
{
string a="My name is rakesh Patidar";
regex reg("(My)(.*)");
smatch match;
if(regex_match(a,reg))
{
cout<<"String a matches regular expression b\n"<<endl;
}
return 0;
}