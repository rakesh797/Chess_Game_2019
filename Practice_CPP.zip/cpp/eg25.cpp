#include<iostream>
using namespace std;
class Movie
{
public:
void start()
{
cout<<"Welcome"<<endl;
}
void interval()
{
cout<<"Interval-Have coffee in Rs.50/-"<<endl;
}
void end()
{
cout<<"Thank You"<<endl;
}
};
class JungleBook:public Movie
{
public:
void interval()
{
interval();
cout<<"and have Coke for Rs.25/-"<<endl;
}
void reelOne()
{
cout<<"Bhageera finds Mowgli"<<endl;
}
void reelTwo()
{
cout<<"Mowgli kills Sher Khan"<<endl;
}
};
int main()
{
JungleBook j;
cout<<"Size of object is "<<sizeof(j)<<endl;
j.start();
j.reelOne();
j.interval();
j.reelTwo();
j.end();
return 0;
}