
int main()
{
int j;
j=60;
new int ;
return 0;
}