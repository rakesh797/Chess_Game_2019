int main()
{
int x;
int &y;
return 0;
}