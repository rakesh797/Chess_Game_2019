#include<malloc.h>
#include<stdio.h>
#include<stdarg.h>
int lcm(int n,...)
{
int *array,i,y,LCM=1,flag,found;
va_list r;
array=(int *)malloc(n*sizeof(int));
va_start(r,n);
for(i=0;i<n;i++) array[i]=va_arg(r,int);
y=2;
while(1)
{
found=0;
for(i=0;i<n;i++) if(array[i]!=1) found=1;
if(found==0) break;
flag=0;
while(1)
{
for(i=0;i<n;i++)
{
if(array[i]%y==0)
{
array[i]=array[i]/y;
flag=1;
}
}
if(flag==1) LCM=LCM*y;
if(flag==0) break;
flag=0;
i=0;
}
++y;
}
return LCM;
}
int hcf(int n,...)
{
int *array,s,i,y=2,HCF=1,flag,found;
va_list r;
array=(int *)malloc(n*sizeof(int));
va_start(r,n);
for(i=0;i<n;i++) array[i]=va_arg(r,int);
s=array[0];
for(i=1;i<n;i++) if(array[i]<s) s=array[i];
if(s==1) return 1;
while(1)
{
found=0;
for(i=0;i<n;i++) if(s==y) found=1;
if(found==1) break;
flag=1;
while(1)
{
for(i=0;i<n;i++)
{
if(array[i]%y==0)
{
array[i]=array[i]/y;
}
else
{
flag=0;
}
}
if(flag!=0) HCF=HCF*y;
if(flag==0) break;
flag=1;
i=0;
}
++y;
}
return HCF;
}
int lcf(int n,...)
{

}
int main()
{
int HCF;
HCF=hcf(3,8,28,12);
printf("%d",HCF);
return 0;
}