#include<iostream>
using namespace std;
class TV
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter the price of TV:";
cin>>p;
}
void printInformation()
{
cout<<"Price of TV is "<<p<<endl;
}
friend int getTotalCost(TV &,Fridge &);
};
class Fridge
{
private:
int p;
public:
void askInformation()
{
cout<<"Enter the price of the Fridge:";
cin>>p;
}
void printInformation()
{
cout<<"Price of Fridge is "<<p<<endl;
}
friend int getTotalCost(TV &,Fridge &);
};
int getTotalCost(TV &a,Fridge &b)
{
return a.p+b.p;
}
int main()
{
TV t;
t.askInformation();
Fridge f;
f.askInformation();
cout<<"Total cost of TV and Fridge is "<<getTotalCost(t,f)<<endl;
return 0;
}